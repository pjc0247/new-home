﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Slowsharp
{
    internal class CallFrame
    {
        public HybInstance _this;
        public SSInterpretMethodInfo Method;
    }
}
