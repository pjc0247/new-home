﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Slowsharp
{
    /*
    internal sealed class EvaluatedArgumentListSyntax : ExpressionSyntax
    {
        public HybInstance[] arguments;

        public override TResult Accept<TResult>(CSharpSyntaxVisitor<TResult> visitor)
        {
            throw new NotImplementedException();
        }

        public override void Accept(CSharpSyntaxVisitor visitor)
        {
            throw new NotImplementedException();
        }

        internal override SyntaxNode GetCachedSlot(int index)
        {
            throw new NotImplementedException();
        }

        internal override SyntaxNode GetNodeSlot(int slot)
        {
            throw new NotImplementedException();
        }
    }
    */
}
