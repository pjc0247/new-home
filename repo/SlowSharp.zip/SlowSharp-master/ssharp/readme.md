ssharp
====
slowsharp cli for demonstrate how it works.

```
ssharp input.csx
```