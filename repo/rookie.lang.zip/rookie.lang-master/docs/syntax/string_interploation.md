
```ruby
name = "jinwoo";
puts (`Hello, my name is {{name}}.`);
```