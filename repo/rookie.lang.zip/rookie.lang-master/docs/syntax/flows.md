Flow control
----

__if~else__
```ruby
a = 10;

if (a > 5) {
    puts("a is greater than 5");
}
```

__for__
```ruby
for (i=0;i<10;i++) 
    puts(i);
```