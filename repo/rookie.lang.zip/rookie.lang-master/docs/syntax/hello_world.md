Hello World!
----

```ruby
class my_first_program {
    @main
    static def main() {
        puts("Hello World!");
    }
}
```