#pragma once

/* Methods */
#define rk_id_new       L"new"
#define rk_id_ctor      L"_ctor"

#define rk_id_getitem   L"__getitem__"
#define rk_id_setitem   L"__setitem__"
#define rk_id_tostring  L"to_string"
#define rk_id_equals    L"equals"

#define rk_id_current   L"current"
#define rk_id_move_next L"move_next"
#define rk_id_get_iter  L"get_iterator"