tests
====

How to write a test
----
### Principle

* Keep each tests simple as possible. The longer the code, the more difficult to debug.

### Ordinary test

Make sure you prepared pair of `.rk` and `.rk.exp`.<br>
`.rk.exp` file should contains the output of the execution.

### Invalid test

Tests that must be failed during compliation should be located under 'invalid/'.
